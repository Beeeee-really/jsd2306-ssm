package cn.tedu.egweibo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Egweibo1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
