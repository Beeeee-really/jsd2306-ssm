package cn.tedu._04weibo;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CommentTests {
}
