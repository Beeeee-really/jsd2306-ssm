package cn.tedu.spring.eg3;

public interface Mapper {
}
