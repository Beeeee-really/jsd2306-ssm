package cn.tedu.spring.eg3;

import org.springframework.stereotype.Component;

@Component(value = "mapperImpl1")
public class MapperImpl1 implements Mapper{
}
