package cn.tedu.spring.eg3;

import org.springframework.stereotype.Component;

@Component
public class MapperImpl2 implements Mapper{
}
