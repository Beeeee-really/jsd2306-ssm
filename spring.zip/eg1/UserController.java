package cn.tedu.spring.eg1;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {
    public void login(){
        System.out.println("登录功能");
    }
}
