package cn.tedu.egmvc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Egmvc2Application {

    public static void main(String[] args) {
        SpringApplication.run(Egmvc2Application.class, args);
    }

}
