package cn.tedu.egmvc2.pojo.dto;

public class ThingDTO {
    private String title;
    private String price;
}
