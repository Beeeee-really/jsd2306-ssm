package cn.tedu.egmybatis2.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserOrdersMapper {
}
